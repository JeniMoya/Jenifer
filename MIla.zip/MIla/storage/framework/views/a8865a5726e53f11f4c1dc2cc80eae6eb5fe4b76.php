<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu Sitio de Videos Educativos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/">Inicio</a></li>
                <li><a href="/cursos">Cursos</a></li>
                <li><a href="/blog">Blog</a></li>
                <li><a href="/contacto">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="hero">
            <h1>Bienvenido a Nuestra Plataforma de Video Educativos</h1>
            <p>Explora una amplia variedad de cursos y contenido educativo de alta calidad.</p>
            <a href="/cursos" class="btn">Explorar Cursos</a>
        </section>
        <section class="cursos">
            <h2>Cursos Destacados</h2>
            <div class="curso">
                <img src="curso1.jpg" alt="Curso 1">
                <h3>Curso de Matemáticas Avanzadas</h3>
                <p>Domina las matemáticas avanzadas con este curso en línea.</p>
                <a href="/cursos/matematicas" class="btn">Ver Curso</a>
            </div>
            <div class="curso">
                <img src="curso2.jpg" alt="Curso 2">
                <h3>Curso de Ciencias de la Computación</h3>
                <p>Aprende programación y ciencias de la computación desde cero.</p>
                <a href="/cursos/computacion" class="btn">Ver Curso</a>
            </div>
            <!-- Agrega más cursos aquí -->
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Tu Sitio de Videos Educativos</p>
    </footer>
</body>
</html>

        <!-- Styles -->
        <style>
            body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
}

header {
    background-color: #333;
    color: black;
    padding: 10px 0;
}

nav ul {
    list-style: none;
    padding: 0;
    text-align: right;
}

nav li {
    display: inline;
    margin-right: 20px;
}

nav a {
    color: wheat;
    text-decoration: none;
}

.main {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.hero {
    background-image: url('hero-bg.jpg');
    background-size: cover;
    text-align: center;
    color: black;
    padding: 100px 0;
}

.hero h1 {
    font-size: 36px;
}

.btn {
    display: inline-block;
    background-color: green;
    color: black;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 20px;
}

.cursos {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.curso {
    flex: 1;
    background-color: white;
    padding: 20px;
    border-radius: 5px;
}

.curso img {
    max-width: 100%;
    height: auto;
}

footer {
    text-align: center;
    padding: 10px;
    background-color: #333;
    color: white;
}

         
        </style>
    </head>
    
</html>
<?php /**PATH C:\laragon\www\MIla\resources\views/welcome.blade.php ENDPATH**/ ?>